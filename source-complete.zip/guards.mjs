import fs from 'node:fs/promises';
const sessions=JSON.parse(await fs.readFile('sessions.json','utf8'));
const limits=sessions.filter(s=>s.capacity!==null).map(s=>`WHEN '${s.id}' THEN ${s.capacity}`).join('\n');
const sql=`CREATE TRIGGER roc_registration_capacity BEFORE INSERT ON registrations
WHEN (SELECT COUNT(*) FROM registrations WHERE session_id=NEW.session_id) >= CASE NEW.session_id ${limits} ELSE 100000 END
BEGIN SELECT RAISE(ABORT,'ROC_FULL'); END;
--> statement-breakpoint
CREATE TRIGGER roc_registration_cancelled BEFORE INSERT ON registrations
WHEN EXISTS(SELECT 1 FROM controls WHERE session_id=NEW.session_id AND status='cancelled')
BEGIN SELECT RAISE(ABORT,'ROC_CANCELLED'); END;
`;
await fs.writeFile('drizzle/0002_session_guards.sql',sql);
const journal=JSON.parse(await fs.readFile('drizzle/meta/_journal.json','utf8'));
if(!journal.entries.some(e=>e.tag==='0002_session_guards')){journal.entries.push({idx:2,version:'6',when:Date.now(),tag:'0002_session_guards',breakpoints:true});await fs.writeFile('drizzle/meta/_journal.json',JSON.stringify(journal,null,2));}
