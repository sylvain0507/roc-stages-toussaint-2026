/* The build injects the public assets and schedule; no private values are bundled. */
const hash=async value=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)))).map(x=>x.toString(16).padStart(2,'0')).join('');
const normal=value=>value.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ');
const isPast=s=>Date.now()>=Date.parse(s.date+'T'+s.start+':00'+(s.date<'2026-10-25'?'+02:00':'+01:00'));
const price=(s,b)=>s.price==='tiny3'?(b.licence==='NC'?'Don libre':'4 €'):s.price==='don'?'Don libre':s.price===0?'Gratuit':s.price+' €';
function secureEqual(a,b){if(typeof a!=='string'||typeof b!=='string'||a.length!==b.length)return false;let diff=0;for(let i=0;i<a.length;i++)diff|=a.charCodeAt(i)^b.charCodeAt(i);return diff===0;}
async function allSessions(db){const [counts,controls]=await db.batch([db.prepare('SELECT session_id, COUNT(*) AS n FROM registrations GROUP BY session_id'),db.prepare('SELECT * FROM controls')]);return SESSIONS.map(s=>{const count=counts.results.find(c=>c.session_id===s.id)?.n??0,control=controls.results.find(c=>c.session_id===s.id);return {...s,count,status:control?.status??'open',note:control?.note??'',past:isPast(s)};});}
export default {async fetch(request,env){
 const url=new URL(request.url),origin=request.headers.get('Origin');
 const allowed=new Set(['https://sylvain0507.github.io',url.origin]);
 const headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'};
 if(origin&&allowed.has(origin)){headers['Access-Control-Allow-Origin']=origin;headers['Vary']='Origin';}
 const json=(value,status=200)=>Response.json(value,{status,headers});
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers:{...headers,'Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type, Authorization'}});
 if(url.pathname.startsWith('/api/')){
  if(origin&&!allowed.has(origin))return json({error:'Origine non autorisée.'},403);
  if(!env.DB)return json({error:'Les inscriptions sont momentanément indisponibles.'},503);
  const db=env.DB;
  const admin=env.ADMIN_KEY&&secureEqual(request.headers.get('Authorization'),`Bearer ${env.ADMIN_KEY}`);
  try{
   if(url.pathname==='/api/sessions'&&request.method==='GET')return json({sessions:await allSessions(db)});
   if(url.pathname.startsWith('/api/admin')&&!admin)return json({error:'Clé d’accès incorrecte.'},401);
   if(url.pathname==='/api/admin'&&request.method==='GET'){
    const data=await db.prepare('SELECT r.id,r.session_id,r.booking_id,b.name,b.email,b.group_name,b.licence,b.created FROM registrations r JOIN bookings b ON b.id=r.booking_id ORDER BY b.created').all();
    return json({sessions:await allSessions(db),registrations:data.results.map(r=>({...r,price:price(SESSIONS.find(s=>s.id===r.session_id),r)}))});
   }
   if(url.pathname==='/api/admin/session'&&request.method==='POST'){
    const body=await request.json();if(!SESSIONS.some(s=>s.id===body.id)||!['open','confirmed','cancelled'].includes(body.status)||typeof body.note!=='string'||body.note.length>400)return json({error:'Modification invalide.'},400);
    if(body.status==='confirmed'){
     const result=await db.prepare("INSERT INTO controls(session_id,status,note) SELECT ?, 'confirmed', ? WHERE (SELECT COUNT(*) FROM registrations WHERE session_id=?)>=4 ON CONFLICT(session_id) DO UPDATE SET status=excluded.status,note=excluded.note").bind(body.id,body.note,body.id).run();
     if(!result.meta.changes)return json({error:'Il faut au moins 4 inscrits pour confirmer cette session.'},409);
    }else await db.prepare('INSERT INTO controls(session_id,status,note) VALUES(?,?,?) ON CONFLICT(session_id) DO UPDATE SET status=excluded.status,note=excluded.note').bind(body.id,body.status,body.note).run();
    return json({ok:true});
   }
   if(url.pathname==='/api/register'&&request.method==='POST'){
    if(Number(request.headers.get('Content-Length'))>10000)return json({error:'Formulaire trop volumineux.'},413);
    const b=await request.json();
    if(typeof b.name!=='string'||b.name.trim().length<3||b.name.length>100||typeof b.email!=='string'||b.email.length>160||!/^\S+@\S+\.\S+$/.test(b.email)||b.consent!==true||!Array.isArray(b.sessions)||!b.sessions.length||b.sessions.length>30||new Set(b.sessions).size!==b.sessions.length||typeof b.id!=='string'||!/^[-a-z0-9]{36}$/.test(b.id)||typeof b.token!=='string'||!/^[-a-z0-9]{36}$/.test(b.token))return json({error:'Vérifiez le nom, l’e-mail et les créneaux choisis.'},400);
    const selected=b.sessions.map(id=>SESSIONS.find(s=>s.id===id));
    if(selected.some(s=>!s||!s.eligibleGroups.includes(b.group)||isPast(s)))return json({error:'Un créneau choisi n’est pas accessible à votre groupe ou a déjà commencé.'},400);
    if(selected.some(s=>s.price==='tiny3')&&!['NTP','NC'].includes(b.licence))return json({error:'Précisez le type de licence Tiny 3.'},400);
    const tokenHash=await hash(b.token);
    const existing=await db.prepare('SELECT token_hash FROM bookings WHERE id=?').bind(b.id).first();
    if(existing){if(secureEqual(existing.token_hash,tokenHash))return json({id:b.id,ok:true});return json({error:'Référence invalide.'},409);}
    const ip=request.headers.get('CF-Connecting-IP');if(ip){const hour=Math.floor(Date.now()/3600000);const key=await hash(env.ADMIN_KEY+ip+hour);await db.prepare('INSERT INTO request_limits(key,count,expires) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1').bind(key,Date.now()+7200000).run();const quota=await db.prepare('SELECT count FROM request_limits WHERE key=?').bind(key).first();if(quota.count>50)return json({error:'Trop de tentatives. Réessayez plus tard.'},429);await db.prepare('DELETE FROM request_limits WHERE expires<?').bind(Date.now()).run();}
    const participantKey=await hash(normal(b.name)+'|'+normal(b.email));
    await db.batch([db.prepare('INSERT INTO bookings(id,token_hash,name,email,group_name,licence,created) VALUES(?,?,?,?,?,?,?)').bind(b.id,tokenHash,b.name.trim(),b.email.trim().toLowerCase(),b.group,b.licence??'',new Date().toISOString()),...selected.map(s=>db.prepare('INSERT INTO registrations(id,booking_id,session_id,participant_key) VALUES(?,?,?,?)').bind(crypto.randomUUID(),b.id,s.id,participantKey))]);
    return json({id:b.id,ok:true});
   }
   if((url.pathname==='/api/booking'||url.pathname==='/api/cancel')&&request.method==='POST'){
    const b=await request.json();if(typeof b.id!=='string'||typeof b.token!=='string')return json({error:'Code personnel invalide.'},400);
    const booking=await db.prepare('SELECT * FROM bookings WHERE id=?').bind(b.id).first();if(!booking||!secureEqual(booking.token_hash,await hash(b.token)))return json({error:'Code personnel introuvable.'},404);
    if(url.pathname==='/api/cancel'){
     if(!Array.isArray(b.sessions)||!b.sessions.length||b.sessions.some(id=>!SESSIONS.some(s=>s.id===id&&!isPast(s))))return json({error:'Ces créneaux ne peuvent plus être annulés en ligne.'},400);
     await db.batch(b.sessions.map(id=>db.prepare('DELETE FROM registrations WHERE booking_id=? AND session_id=?').bind(b.id,id)));
    }
    const regs=await db.prepare('SELECT session_id FROM registrations WHERE booking_id=?').bind(b.id).all();const sessions=(await allSessions(db)).filter(s=>regs.results.some(r=>r.session_id===s.id)).map(s=>({...s,priceLabel:price(s,booking)}));
    return json({name:booking.name,group:booking.group_name,sessions});
   }
   return json({error:'Requête inconnue.'},404);
  }catch(e){const msg=String(e);if(msg.includes('UNIQUE constraint'))return json({error:'Ce nageur est déjà inscrit à l’un des créneaux choisis. Retirez ce créneau ou retrouvez son inscription avec son code personnel.'},409);if(msg.includes('ROC_FULL'))return json({error:'Un créneau est désormais complet. Actualisez les effectifs puis modifiez votre sélection.'},409);if(msg.includes('ROC_CANCELLED'))return json({error:'Un créneau a été annulé par le club. Actualisez le planning.'},409);console.error('ROC API unavailable',e?.name);return json({error:'L’enregistrement n’a pas pu être confirmé. Vos choix sont conservés : vous pouvez réessayer.'},503);}
 }
 const path=url.pathname==='/'?'/index.html':url.pathname;
 const asset=ASSETS[path];if(!asset)return new Response('Page introuvable',{status:404});
 const bytes=Uint8Array.from(atob(asset.body),c=>c.charCodeAt(0));return new Response(bytes,{headers:{'Content-Type':asset.type,'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self' https://roc-stages-toussaint-2026.sylvainbeq.chatgpt.site; object-src 'none'; base-uri 'none'"}});
}};
